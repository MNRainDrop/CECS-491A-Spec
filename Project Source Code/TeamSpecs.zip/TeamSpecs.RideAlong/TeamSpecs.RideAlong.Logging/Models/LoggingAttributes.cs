﻿namespace TeamSpecs.RideAlong.Logging.Models
{
    public class LogAttributes
    {
        public int LogID { get; set; }
        public DateTime Time { get; set; }
        public string? Message { get; set; }
    }
}
